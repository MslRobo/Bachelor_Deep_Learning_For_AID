# Vehicle Crash Dataset > 2023-01-22 9:49pm
https://universe.roboflow.com/object-detection-3iugc/vehicle-crash-dataset

Provided by a Roboflow user
License: CC BY 4.0

